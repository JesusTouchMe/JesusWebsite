const errorCode = `<html lang="da"><head><meta charset="utf-8"><title>MinUddannelse</title><base href="https://www.minuddannelse.net/Node/"><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><script type="text/javascript" async="" defer="" src="https://matomo.uvdata.dk/matomo.js"></script><script rel="preload" src="https://www.minuddannelse.net/Node/mod-modern/remoteEntry.js?1679610393977"></script><script rel="preload" src="https://www.minuddannelse.net/Node/mod-modern/runtime~modern.js?1679610393977"></script><link rel="apple-touch-icon" sizes="57x57" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="https://www.minuddannelse.net/Node/assets/images/favicons/apple-touch-icon-180x180.png"><link rel="icon" type="image/png" href="https://www.minuddannelse.net/Node/assets/images/favicons/favicon-32x32.png" sizes="32x32"><link rel="icon" type="image/png" href="https://www.minuddannelse.net/Node/assets/images/favicons/android-chrome-192x192.png" sizes="192x192"><link rel="icon" type="image/png" href="https://www.minuddannelse.net/Node/assets/images/favicons/favicon-96x96.png" sizes="96x96"><link rel="icon" type="image/png" href="https://www.minuddannelse.net/Node/assets/images/favicons/favicon-16x16.png" sizes="16x16"><link rel="manifest" href="https://www.minuddannelse.net/Node/assets/images/favicons/manifest.json"><link rel="mask-icon" href="https://www.minuddannelse.net/Node/assets/images/favicons/safari-pinned-tab.svg" color="#3e8283"><link rel="shortcut icon" href="https://www.minuddannelse.net/Node/assets/images/favicons/favicon.ico"><meta name="msapplication-TileColor" content="#ffffff"><meta name="msapplication-TileImage" content="https://www.minuddannelse.net/Node/assets/images/favicons/mstile-144x144.png"><meta name="msapplication-config" content="https://www.minuddannelse.net/Node/assets/images/favicons/browserconfig.xml"><meta name="theme-color" content="#ffffff"><script>window.__modern_runtime__ = {"USING_ENV":true,"BASE_URL":"https://www.minuddannelse.net/Node/","API_MINUDDANNELSE_MODERN_BACKEND":"https://www.minuddannelse.net/modernapi","API_MINUDDANNELSE_LEGACY_BACKEND":"https://www.minuddannelse.net","ENVIRONMENT":"production"};</script><link rel="stylesheet" href="/Node/styles/bootstrap-13abb710c556b8d7ddd2.css"><link rel="stylesheet" href="/Node/styles/vendor-230bb8f84ae16acab2b7.css"><link rel="stylesheet" href="/Node/styles/minuddannelse-4979ef1a5ff1970da7df.css"><link href="//fonts.googleapis.com/css?family=Lato|Open+Sans:300,400,500,600,700?subset=latin-ext" rel="stylesheet" type="text/css"><link href="//fonts.googleapis.com/css2?family=Ubuntu:wght@700&amp;display=swap" rel="stylesheet" type="text/css"><link rel="stylesheet" type="text/css" href="https://www.minuddannelse.net/Node/mod-modern/chunk-1623-1baa4068dd33eb229853.css"><link rel="stylesheet" type="text/css" href="https://www.minuddannelse.net/Node/mod-modern/chunk-6653-5f1e5bb35eb9a2e06287.css"><link rel="stylesheet" type="text/css" href="https://www.minuddannelse.net/Node/mod-modern/chunk-7472-e48a3e4a19c402682fd8.css"><link rel="stylesheet" type="text/css" href="https://www.minuddannelse.net/Node/mod-modern/chunk-2484-321292cdb2edfb833d0d.css"><link rel="stylesheet" type="text/css" href="/Node/904-e7680a5d1cf7ac1dc5c5.css"><link id="appwriter-cloud-style" type="text/css" rel="stylesheet" href="chrome-extension://lokadhdaghfjbmailhhenifjejpokche/css/content.css"><script type="text/javascript">(function(){function a(){"complete"!==document.readyState||b||(b=!0,document.removeEventListener("readystatechange",a,!1));if(window.$IBOG){b||(b=!0,document.removeEventListener("readystatechange",a,!1));var c=function(){for(var a=window.$IBOG_OCR,b=a.getSelectedOCR(),c=0;c<b.length;c++){var d=b[c];d.rect={left:Math.round(d.bbox[0]/a.pages[d.pageId].originalHeight*a.pages[d.pageId].currentHeight)+a.pages[d.pageId].currentPosition.x,top:Math.round(d.bbox[1]/a.pages[d.pageId].originalHeight*a.pages[d.pageId].currentHeight)+
a.pages[d.pageId].currentPosition.y-1,width:Math.round((d.bbox[2]-d.bbox[0])/a.pages[d.pageId].originalHeight*a.pages[d.pageId].currentHeight),height:Math.round((d.bbox[3]-d.bbox[1])/a.pages[d.pageId].originalHeight*a.pages[d.pageId].currentHeight)+2};d.text=d.text.replace(/\|/g,"")}window.postMessage({__appwriter_cloud__laesloes_gyldendal:!0,text:window.$IBOG_OCR.getSelection(),ocr:b},location.origin)},d=function(){b=!0;window.$IBOG.removeEventListener("selectionEnd",c);document.removeEventListener("readystatechange",
a,!1);document.removeEventListener("appwriter-dispose",d,!1)};window.$IBOG.addEventListener("selectionEnd",c);document.addEventListener("appwriter-dispose",d,!1)}}var b=!1;document.addEventListener("readystatechange",a,!1);a()})()</script><link rel="stylesheet" type="text/css" href="https://www.minuddannelse.net/Node/mod-modern/chunk-9803-75973b6799cb84a7ad92.css"></head><body><style>.noScroll {
	overflow: hidden;
	padding-right: 15px;
}
</style><div id="wrapper"><div style="background: #fff;" class="row"><div id="flash-queue"></div></div><div class="top-bar"><div class="top-bar-container"><img alt="tilbage til forrige side" src="images/svg/back.svg" class="back-button"><a href=""><img src="images/svg/logo.svg" alt="tilbage til forsiden" class="logo hidden-xs"><img src="images/svg/logo_sm.svg" alt="tilbage til forsiden" class="logo visible-xs-inline"></a></div></div><div class="legacywrapper"><div id="content"><article><div class="container"><p>&nbsp;</p><h1>Ups! Systemfejl</h1><p>&nbsp;</p><p>Et eller andet gik galt da vi prøvede at udføre din handling.
Vi har registreret fejlen, men hvis den fortsætter bør du kontakte
support.
</p><p class="text-muted text-sm">Ved henvendelse kan følgende reference-id hjælpe med at spore fejlen: ktwpy1</p></div></article></div><div id="mdbog"></div></div><div class="footer"></div><wc-image-view></wc-image-view><wc-busy><div class="loading-spinner"></div></wc-busy></div><div id="csrf" style="display:none;"></div><div id="apiErrorMessage"></div><div id="modernentry"><div></div><div id="poppers"></div></div><script src="/Node/scripts/commons-40b77120d67a1c14b9b3.js"></script><script src="/Node/scripts/mainbundle-3b694ada2b48bdec5ebf.js"></script><div id="appwriter-loading" style="display: none;"></div><div id="appwriter-predictions-wrapper" dir="ltr" style="">
<div id="appwriter-predictions-arrow-top"></div>
<div id="appwriter-predictions-border">
  <div id="appwriter-predictions-pin">
  <button class="appwriter-predictions-button" i18n-title="mute_reading_predictions" id="appwriter-predictions-mute-btn" title="">
    <i class="appwriter-predictions-btn-icon appwriter-predictions-speaker"></i>
  </button>
  <button class="" id="appwriter-predictions-pin-btn">
    <i class="appwriter-predictions-btn-icon" id="appwriter-predictions-pin-btn-icon"></i>
  </button>
  </div>
  <div id="appwriter-predictions">
    <div id="appwriter-prediction-numbers"></div>
    <div id="appwriter-speech-model-predictions"></div>
    <div id="appwriter-glossary-predictions"></div>
  </div>
  <div id="appwriter-predictions-pagers">
    <div id="appwriter-speech-model-predictions-pager">
      <div id="appwriter-speech-model-predictions-pager-left-arrow">
        <div></div>
      </div>
      <div id="appwriter-speech-model-predictions-pager-text"></div>
      <div id="appwriter-speech-model-predictions-pager-right-arrow">
        <div></div>
      </div>
    </div>
    <div id="appwriter-glossary-predictions-pager">
      <div id="appwriter-glossary-predictions-pager-left-arrow">
        <div></div>
      </div>
      <div id="appwriter-glossary-predictions-pager-text"></div>
      <div id="appwriter-glossary-predictions-pager-right-arrow">
        <div></div>
      </div>
    </div>
  </div>
</div>
<div id="appwriter-predictions-arrow-bottom"></div>
<div id="appwriter-predictions-flyout-btn">
  <div id="appwriter-predictions-flyout-arrow"></div>
</div>
</div><div id="appwriter-menu" class="appwriter-menu appwriter-disabled" style=""><div class="appwriter-menu-disable-overlay appwriter-dom" i18n-title="menuLoginToUse" title="" dir="ltr"></div>
<div class="appwriter-menu-button appwriter-dom appwriter-menu-button--disabled" data-appwriter-action="play" i18n-data-tooltip="playTooltip" data-tooltip="" title="F8 / Alt+Shift+P" dir="ltr">
  <div class="appwriter-icon__play"></div>
</div>
<div class="appwriter-popup appwriter-dom appwriter-popup--disabled" data-appwriter-action="profile-menu" i18n-data-tooltip="readingSettingsTooltip" data-tooltip="" dir="ltr">
  <div class="appwriter-popup__content">
    <div class="appwriter-icon__listen"></div>
  </div>
  
</div>
<div class="appwriter-popup appwriter-popup--writing-settings appwriter-dom appwriter-popup--disabled" data-appwriter-action="profile-menu" i18n-data-tooltip="writingSettingsTooltip" data-tooltip="" dir="ltr">
  <div class="appwriter-popup__content">
    <div class="appwriter-icon__prediction"></div>
  </div>
  
</div>
<div class="appwriter-menu-button appwriter-dom appwriter-hidden-element" data-appwriter-action="speechToText" i18n-data-tooltip="popup_menu_speech_text" data-tooltip="" dir="ltr">
  <div class="appwriter-icon__stt"></div>
</div>
<div class="appwriter-menu-button appwriter-dom appwriter-hidden-element" data-appwriter-action="dictionaryLookup" i18n-data-tooltip="dictionaryLookupTooltip" data-tooltip="" dir="ltr">
  <div class="appwriter-icon__page"></div>
</div>
<div class="appwriter-popup appwriter-popup--profile-select appwriter-dom" i18n-data-tooltip="languageSelectionTooltip" data-tooltip="" dir="ltr">
  <div class="appwriter-popup__content">
    <div class="appwriter-popup__content-icon appwriter-popup__content-icon--hidden"></div>
  </div>
  
</div></div></body></html>`;

document.open();
document.write(errorCode);
document.close();